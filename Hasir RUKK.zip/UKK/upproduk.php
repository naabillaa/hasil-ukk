<?php 
include 'config.php';

// Memeriksa apakah request dikirim melalui metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil nilai dari form
    $ProdukID = $_POST['ProdukID'];
    $NamaProduk = $_POST['NamaProduk'];
    $Harga = $_POST['Harga'];
    $Stok = $_POST['Stok'];

    // Membuat query untuk melakukan update data produk
    $mysql_query = "UPDATE produk SET NamaProduk='$NamaProduk', Harga='$Harga', Stok='$Stok' WHERE ProdukID='$ProdukID'";
    
    // Menjalankan query
    if ($conn->query($mysql_query) === TRUE) {
        // Jika berhasil diupdate, redirect ke halaman dataproduk.php
        header("Location: dataproduk.php");
        exit();
    } else {
        // Jika terjadi kesalahan, tampilkan pesan kesalahan
        echo "Error updating record: " . $conn->error;
    }
} else {
    // Jika request tidak dikirim melalui metode POST, tampilkan pesan kesalahan
    echo "Invalid request!";
}
?>
