<?php 
include 'config.php';
session_start();
 
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit(); // Terminate script execution after the redirect
}

$DetailID = $_GET['DetailID'];
$sqlDetail= "DELETE FROM detail_penjualan WHERE DetailID='$DetailID'";
$conn->query($sqlDetail);
  

header("Location: admin/examples/detaill.php");
exit();

?>

