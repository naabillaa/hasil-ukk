<?php 
include 'config.php';
session_start();
 
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit(); // Terminate script execution after the redirect
}

if(isset($_POST['submit'])){
    $DetailID = $_POST['DetailID'];
    $PenjualanID = $_POST['PenjualanID'];
    $ProdukID = $_POST['ProdukID'];
    $JumlahProduk = $_POST['JumlahProduk'];
    $SubTotal = $_POST['SubTotal'];


    $query_update = "UPDATE detail_penjualan SET PenjualanID='$PenjualanID', ProdukID='$ProdukID', JumlahProduk='$JumlahProduk', SubTotal='$SubTotal' WHERE DetailID='$DetailID'";
    
    if(mysqli_query($conn, $query_update)){
        echo "Data berhasil diperbarui.";
        // Redirect to the page with the updated data
        header("Location: admin/examples/detail.php");
        exit(); // Terminate script execution after the redirect
    } else {
        echo "ERROR: Gagal memperbarui data. " . mysqli_error($conn);
    }
}

$DetailID = $_GET['DetailID'];

$query = "SELECT * FROM detail_penjualan WHERE DetailID = $DetailID ";

$result = mysqli_query($conn, $query);

$row = mysqli_fetch_array($result);

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <title>Edit Siswa</title>
</head>

<body>

    <div class="container" style="margin-top: 80px">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        EDIT Produk
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            
                            <div class="form-group">
                                <label>Nama Produk</label>
                                <input type="text" name="PenjualanID" value="<?php echo $row['PenjualanID'] ?>" placeholder=" Nama Produk " class="form-control">
                                <input type="hidden" name="DetailID" value="<?php echo $row['DetailID'] ?>">
                            </div>

                            <div class="form-group">
                                <label>ProdukID</label>
                                <input type="number" name="ProdukID" value="<?php echo $row['ProdukID'] ?>" placeholder="ProdukID" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>JumlahProduk</label>
                                <input type="number" name="JumlahProduk" value="<?php echo $row['JumlahProduk'] ?>" placeholder="JumlahProduk" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Sub Total</label>
                                <input type="number" name="SubTotal" value="<?php echo $row['SubTotal'] ?>" placeholder="JumlahProduk" class="form-control">
                            </div>
                            
                            <button type="submit" name="submit" class="btn btn-success">UPDATE</button>
                            <button type="reset" class="btn btn-warning">RESET</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
