<?php
include 'config.php';
session_start();
 
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit(); // Terminate script execution after the redirect
}
if(isset($_POST['submit'])){
    // Ambil nilai yang dikirimkan melalui form
    $PenjualanID = $_POST['PenjualanID'];
    $TanggalPenjualan = $_POST['TanggalPenjualan'];
    $SubTotal = $_POST['SubTotal'];
    $DetailID = $_POST['DetailID'];
    $ProdukID = $_POST['ProdukID'];
    $JumlahProduk = $_POST['JumlahProduk'];
    
    // Buat query untuk menambahkan data ke tabel penjualan
    $sql_penjualan = "INSERT INTO penjualan (PenjualanID, TanggalPenjualan, SubTotal) VALUES ('$PenjualanID', '$TanggalPenjualan', '$SubTotal')";
    if ($conn->query($sql_penjualan) === TRUE) {
        // Buat query untuk menambahkan data ke tabel detail_penjualan
        $sql_detail = "INSERT INTO detail_penjualan (DetailID, PenjualanID, ProdukID, JumlahProduk, SubTotal) VALUES ('$DetailID', '$PenjualanID', '$ProdukID', '$JumlahProduk', '$SubTotal')";
        if ($conn->query($sql_detail) === TRUE) {
            // Kurangi stok produk
            $sql_update_stok = "UPDATE produk SET Stok = Stok - $JumlahProduk WHERE ProdukID = '$ProdukID'";
            if ($conn->query($sql_update_stok) === TRUE) {
                // Redirect ke halaman detail
                header("Location: admin/examples/detail.php");
            } else {
                echo "Error updating stock: " . $conn->error;
            }
        } else {
            echo "Error adding to detail_penjualan table: " . $conn->error;
        }
    } else {
        echo "Error adding to penjualan table: " . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Niagahoster Tutorial</title>
    <script>
        function updateSubTotal() {
            var hargaProduk = document.getElementById("ProdukID").options[document.getElementById("ProdukID").selectedIndex].getAttribute('data-harga');
            var jumlahProduk = document.getElementById("JumlahProduk").value;
            var subTotal = hargaProduk * jumlahProduk;
            document.getElementById("SubTotal").value = subTotal;
        }
    function addProduct() {
        var produkID = document.getElementById("ProdukID").value;
        var produkNama = document.getElementById("ProdukID").options[document.getElementById("ProdukID").selectedIndex].text;
        var hargaProduk = document.getElementById("ProdukID").options[document.getElementById("ProdukID").selectedIndex].getAttribute('data-harga');
        var jumlahProduk = document.getElementById("JumlahProduk").value;
        var subTotal = hargaProduk * jumlahProduk;

        // Buat element baru untuk menampilkan produk yang ditambahkan
        var newItem = document.createElement("div");
        newItem.innerHTML = produkNama + " (ID: " + produkID + ") - Jumlah: " + jumlahProduk + " - Subtotal: " + subTotal;
        document.getElementById("produkList").appendChild(newItem);

        // Update total harga
        var totalHarga = parseFloat(document.getElementById("SubTotal").value) + subTotal;
        document.getElementById("SubTotal").value = totalHarga;
    }

    </script>
</head>
<body>
    <div class="container">
        <form action="" method="POST" class="">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Tambah Penjualan</p>
            <div class="input-group">
                <input type="number" placeholder="Detail ID" name="DetailID" required>
            </div>
            <div class="input-group">
                <input type="number" placeholder="ID Penjualan" name="PenjualanID" required>
            </div>
               
            <div class="input-group">
                <input type="number" placeholder="Jumlah Produk" name="JumlahProduk" id="JumlahProduk" required>
            </div>

            <div class="input-group">
                <select name="ProdukID" id="ProdukID" style="width:200px;" onchange="updateSubTotal()">
                <option >Pilih Produk</option>
                    <?php
                    include "config.php";
                    //query menampilkan produk ke dalam combobox
                    $query    =mysqli_query($conn, "SELECT * FROM produk ORDER BY ProdukID");
                    while ($data = mysqli_fetch_array($query)) {
                    ?>
                    <option value="<?=$data['ProdukID'];?>" data-harga="<?=$data['Harga'];?>"><?php echo $data['NamaProduk'];?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
           
            <div class="input-group">
                <input type="text" placeholder="Sub Total" name="SubTotal" id="SubTotal" onchange="updateSubTotal()" readonly >
            </div>
            <div class="input-group">
                <input type="Date" placeholder="Tanggal Penjualan" name="TanggalPenjualan" required>
            </div>
         
            <div class="input-group">
                <button name="submit" class="btn">Tambah</button>
            </div>
        </form>
    </div>

</body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</html>
