<?php 
include 'config.php';
session_start();
 
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit(); // Terminate script execution after the redirect
}

// Tangani pencarian
if(isset($_POST['submit'])){
    $search = $_POST['search'];
    // Query dengan filter pencarian
    $query = "SELECT * FROM detail_penjualan WHERE ProdukID LIKE '%$search%'";
    $query2 = "SELECT * FROM penjualan WHERE PenjualanID LIKE '%$search%'";
} else {
    // Query tanpa filter pencarian
    $query = "SELECT * FROM detail_penjualan";
  $query2 = "SELECT * FROM penjualan";

}

$result = mysqli_query($conn, $query);
$result2 = mysqli_query($conn, $query2);
?>

<!DOCTYPE html>
<html>
<head>
 <title>Membuat CRUD Dengan PHP Dan MySQL - Menampilkan data dari database</title>
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="sstyle.css">
</head>
<body><center>
<div class="pos-f-t">
  <div class="collapse" id="navbarToggleExternalContent">
    <div class="bg-dark p-2">
    <div class="input-group">
    <form action="logout.php" method="POST" class="login-email">
                <button type="submit"  class="btn">Logout</button>
                </form>
            </div>
    </div>
  </div>
  <nav class="navbar navbar-dark bg-dark">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </nav>
</div>
 <div class="judul"> 
 <h1>Data Produk</h1>
 <h2>Menampilkan data dari database</h2>
 </div>
 <br/>

 <br/>
 <a class="tombol" href="indetail.php">+ Tambah Data Baru</a>
 
 <h3>Data Detail Penjualan</h3>
 <form method="post" action="">
 <input type="button" value="Go Back!" onclick="history.go(-1)">
 <input type="text" name="search" placeholder="Cari disini" value="<?php if(isset($search)){echo $search;} ?>">
 <input type="submit" name="submit" value="Search">
</form>

<form method="post" action="">
 <input type="submit" name="show_all" value="Tampilkan Semua">
</form>


<table border="1" cellspacing="0" cellpadding="10">
  <tr>
    <th>NO</th>
    <th>ID Detail</th>
    <th>ID Penjualan</th>
    <th>ID Produk</th>
    <th>Jumlah Produk</th>
    <th>Subtotal</th>
    <th>Subtotal</th>
    <th>Tanggal Penjualan</th>
    <th>Total Harga</th>

    <th>Aksi</th>
  </tr>

<?php
if (mysqli_num_rows($result) > 0) {
  $sn=1;
  while($data = mysqli_fetch_assoc($result)) {

    if (mysqli_num_rows($result2) > 0) {
      while($data2 = mysqli_fetch_assoc($result2)) {

 ?>
 <tr>
   <td><?php echo $sn; ?></td>
   <td><?php echo $data['DetailID']; ?></td>
   <td><?php echo $data['PenjualanID']; ?></td>
   <td><?php echo $data['ProdukID']; ?></td>
   <td><?php echo $data['JumlahProduk']; ?></td>
   <td><?php echo $data['SubTotal']; ?></td>
   <td><?php echo $data2['TanggalPenjualan']; ?></td>
   <td><?php echo $data2['SubTotal']; ?></td>
   <td>
       <a class='edit' href='editproduk.php?ProdukID=<?php echo $data['ProdukID']; ?>'>Edit</a> |
       <a class='hapus' href='hapusdetail.php?ProdukID=<?php echo $data['ProdukID']; ?>'>Hapus</a>
   </td>
 </tr>
 <?php
  $sn++;
  }}}
} else {
 ?>
  <tr>
    <td colspan="7">No data found</td>
  </tr>
 <?php
}
?>
</table>

</body></center>
</html>
